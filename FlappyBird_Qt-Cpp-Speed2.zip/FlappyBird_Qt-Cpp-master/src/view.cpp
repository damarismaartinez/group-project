#include "view.h"
#include <QKeyEvent>
#include <QApplication>

View::View()
    : QGraphicsView(), m_gameScene(new GameScene(this)), m_titleScene(new TitleScene(this)),
      m_gameOverScene(new GameOverScene(this))
{
    setScene(m_titleScene);
    resize(Game::RESOLUTION.width()+2, Game::RESOLUTION.height()+2);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    createConnections();
}

void View::createConnections()
{
    auto switchToScene = [this](QGraphicsScene* scene) {
        setScene(scene);
        if (scene == m_gameScene) {
            m_gameScene->init();
        } else if (scene == m_gameOverScene) {
            m_gameOverScene->updateScore();
        }
    };

    connect(m_titleScene, &TitleScene::gameActivated, [this, switchToScene]() {
        switchToScene(m_gameScene);
    });

    connect(m_gameOverScene, &GameOverScene::gameActivated, [this, switchToScene]() {
        switchToScene(m_gameScene);
    });

    connect(m_gameScene, &GameScene::gameOverActivated, [this, switchToScene]() {
        switchToScene(m_gameOverScene);
    });
}


void View::keyPressEvent(QKeyEvent *event)
{
    switch (event->key()) {
        case Qt::Key_Escape:
            QApplication::instance()->quit();
        break;
    }
    QGraphicsView::keyPressEvent(event);
}
